package com.example.mp3player;

import java.io.File;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

//import com.example.menu.MainActivity;
//import com.example.menu.R;





//import com.example.final_music2.R;

import android.R;
import android.widget.AbsSeekBar;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.view.MenuItemCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;




public class MainActivity  extends ListActivity implements OnClickListener {
	ArrayList<String> s_name=new ArrayList<String>();
	ArrayList<String> index=new ArrayList<String>();
	
    ArrayAdapter<String>  songList;
	EditText edittext;
	ListView listview;
	static int next;
    
	
    HashMap<String, String> song = new HashMap<String, String>();
	SeekBar s;
	Button b1,b2,b3,b4,b5;
	Handler seekHandler = new Handler();
	MediaMetadataRetriever mmr = new MediaMetadataRetriever();
	public MediaPlayer mp=new MediaPlayer();
	private ArrayList<File> fileList = new ArrayList<File>();
	boolean isPlaying=false;
	int m=1;
	int i=10,duration;
	int a=0;
	
	//it builds the notification on the notification panel
	 NotificationCompat.Builder notification;
	//assigns unique id to our notification 
	 private static final int uniqueID=45612;
	
	 
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
		//fgetListView().setBackgroundResource(R.drawable.ferr1);
		
		 notification=new NotificationCompat.Builder(this);
		 //setting autocancel to false so that notification can stay for more than one click
         notification.setAutoCancel(false);
		
	  //  listview=(ListView) findViewById(R.id.list);
         edittext=(EditText) findViewById(R.id.jjj);
		s=(SeekBar) findViewById(R.id.seekBar1);
		b1=(Button) findViewById(R.id.button1);
	  b2=(Button) findViewById(R.id.button2);
		//imgbutton =(ImageButton)findViewById(R.id.button2);
	  b3=(Button) findViewById(R.id.button3);
	    b4=(Button) findViewById(R.id.button4);
	    b5=(Button) findViewById(R.id.button5);
	    
	    b1.setOnClickListener(this);
		b3.setOnClickListener(this);
		b4.setOnClickListener(this);
		
	    
	        
	        b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(),"SHUFFLE" ,Toast.LENGTH_SHORT).show();
				mp.reset();
			
				  
	  		    try {
	  		    	
					mp.setDataSource(song.get(s_name.get(next+i)));
					  notification.setSmallIcon(R.drawable.ic_delete);
			      	   notification.setTicker("MP3");
			      	   notification.setWhen(System.currentTimeMillis());
			      	   notification.setContentTitle("mp3");
					   notification.setContentText(s_name.get(next+i));
					  
			      	   NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
			      	   nm.notify(uniqueID,notification.build());
					  i=i+7;
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  		    try {
					mp.prepare();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  	        mp.start();
	  	        s.setMax(mp.getDuration());
	  	      
	  	        seekUpdation();
	  	      
	  	        
				
			}
		});
	        
	        
	  	    b2.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			 if(isPlaying==false){
				
			 
  			        mp.pause();}
  		         else{
  		        	

  				    mp.start();
  		        	}isPlaying=!isPlaying;
			
		}
	});
	  	    b3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				 mp.stop();
					Toast.makeText(getApplicationContext(),"PREV SONG " ,Toast.LENGTH_SHORT).show();
					 mp.reset();
			
					next=next-1;
					
			         try{
					 mp.setDataSource(song.get(s_name.get(next)));
					 notification.setSmallIcon(R.drawable.ic_btn_speak_now);
			      	   notification.setTicker("MP3");
			      	   notification.setWhen(System.currentTimeMillis());
			      	   notification.setContentTitle("mp3");
					   notification.setContentText(s_name.get(next));
					   NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
			      	   nm.notify(uniqueID,notification.build());
			         }catch(Exception e){}
			         try{
			  		 mp.prepare();}catch(Exception e){}
			  	     mp.start();
			  	     s.setMax(mp.getDuration());
			  	     //m=m+1;
			  	     
			  	     seekUpdation();
			

		
			}});
	  	  b4.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			  mp.stop();
				Toast.makeText(getApplicationContext(),"NEXT SONG " ,Toast.LENGTH_SHORT).show();
				 mp.reset();
		
				next=next+1;
				
		         try{
				 mp.setDataSource(song.get(s_name.get(next)));
				 notification.setSmallIcon(R.drawable.ic_menu_sort_alphabetically);
		      	   notification.setTicker("MP3");
		      	   notification.setWhen(System.currentTimeMillis());
		      	   notification.setContentTitle("mp3");
				   notification.setContentText(s_name.get(next));
				   NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		      	   nm.notify(uniqueID,notification.build());
		         }catch(Exception e){}
		         try{
		  		 mp.prepare();}catch(Exception e){}
		  	     mp.start();
		  	     s.setMax(mp.getDuration());
		  	     //m=m+1;
		  	     
		  	     seekUpdation();
		}
	});
    	
	  	  
	  
	      s.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
				// TODO Auto-generated method stub
				 if (arg2 && mp.isPlaying()) {
			
			           
			            mp.seekTo(arg1);
				
			}}
		 
		
		});
		       	
       
     
	
		
		
	
		
		edittext.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
			
				MainActivity.this.songList.getFilter().filter(arg0);
				 
			   
				
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
				
			}
		});
		
		
		
		b5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				mp.pause();
				Intent v=new Intent(MainActivity.this,Video.class);
				startActivity(v);
				
			}
			
		});
		
		//clicking on the notification will take us to the notify class  
   	   Intent intent=new Intent(this,Notify.class);
   	   PendingIntent pendingIntent=PendingIntent.getActivity(this,0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
   	   notification.setContentIntent(pendingIntent);
   	//manages notification using unique id and notification manager   
   	   NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
   	   nm.notify(uniqueID,notification.build());
 
		//reading all directories in phone and sd
		File root = Environment.getExternalStorageDirectory();
		
		//method for filtering mp3 files
		getfile(root);
		
				
       
}
	
	

	
	//using runnable interface of thread 
	   Runnable run = new Runnable()
	      {
	    	  public void run()
	    	  {  
	    		  
	    		 seekUpdation();
	    		 
	    	
	    		 
	    	  }
	           }; 
	           
	           //method to update seekhandler position according to the song
	           public void seekUpdation() {
	        	   
	        		 
		    	
	       		s.setProgress(mp.getCurrentPosition());
	       		seekHandler.postDelayed(run,1000);
	       //
	       //		Toast.makeText(getApplicationContext(),""+mp.getCurrentPosition(),Toast.LENGTH_SHORT).show(); 
	           } 
	       
	      
	@Override
	protected void onListItemClick(ListView l, View v, final int position, long id) {
		// TODO Auto-generated method stub
        //   duration=mp.getDuration();
        //   Toast.makeText(getApplicationContext(),""+duration,Toast.LENGTH_SHORT).show(); 
            
           notification.setSmallIcon(R.drawable.ic_dialog_alert);
      	   notification.setTicker("MP3");
      	   notification.setWhen(System.currentTimeMillis());
      	   notification.setContentTitle("mp3");
      	   notification.setContentText(s_name.get(position));
      	   
      	//clicking on the notification will take us to the notify class  
      	   Intent intent=new Intent(this,Notify.class);
      	   PendingIntent pendingIntent=PendingIntent.getActivity(this,0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
      	   notification.setContentIntent(pendingIntent);
      	//manages notification using unique id and notification manager   
      	   NotificationManager nm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
      	   nm.notify(uniqueID,notification.build());
    
        	
        	
		 
        	song.get(s_name.get(position));
        
        //	Toast.makeText(getApplicationContext(),"" + song.get(s_name.get(position)) ,Toast.LENGTH_SHORT).show();
        	Toast.makeText(getApplicationContext(),"Playing" ,Toast.LENGTH_SHORT).show();  
        	try{
            mp.reset();
           
           
  		    mp.setDataSource(song.get(s_name.get(position)));
  		    mp.prepare();
  	        mp.start();
  			next=position;
  	        s.setMax(mp.getDuration());
  	       
  	        seekUpdation();
        	}catch(Exception e){};  	        
  	  	
  	        
  	        
  	      
      
		}
	
    
	public ArrayList<String> getfile(File dir) {
		File  listFile[]= dir.listFiles();
		if (listFile != null && listFile.length > 0) {
			for (int i = 0; i < listFile.length; i++) {

				if (listFile[i].isDirectory()) {
					getfile(listFile[i]);

				} else if (listFile[i].getName().endsWith(".mp3"))
							
					{
					      
                        //song.put("songTitle", listFile[i].getName());
                        //song.put("songPath", listFile[i].getPath());
                        //songsList.add(song);
					//	a.add(listFile[i].getPath());
						//s_name=String.listFile;
					   song.put(listFile[i].getName(), listFile[i].getPath());
					  
				       s_name.add(listFile[i].getName());	
						
					}
				else
				{
					continue;
				}
				}

		       Collections.sort(s_name,String.CASE_INSENSITIVE_ORDER);
               songList = new ArrayAdapter<String>(this,R.layout.text,R.id.textView1,s_name);
		
		     setListAdapter(songList);
	        	
		 
		
		}
		return s_name;
	}

	

	

//if back button is pressed it does not terminate that activity
@Override
public void onBackPressed() {
	// TODO Auto-generated method stub
	//super.onBackPressed();
	 moveTaskToBack(true);
}


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

	
}
	

	



	
		
		
		
	





	