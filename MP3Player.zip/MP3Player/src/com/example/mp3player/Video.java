package com.example.mp3player;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import android.R;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Video extends ListActivity {
	

     MainActivity m=new MainActivity();
     
	 HashMap<String, String> vi = new HashMap<String, String>();
	 ArrayList<String> video_name=new ArrayList<String>();
	 ListView l;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video);

		Toast.makeText(getApplicationContext(),"VIDEO PLAYER" ,Toast.LENGTH_SHORT).show();
        File root = Environment.getExternalStorageDirectory();
		
		//method for filtering mp3 files
		getfilev(root);
		
		

}
	
	protected void onListItemClick(ListView l, View v, final int position, long id) {
	String video_path=vi.get(video_name.get(position));
	Intent i=new Intent(Video.this,Video_player.class);
	i.putExtra("video_path",video_path);
	startActivity(i);
	
			
	       
	}
	
	
	public ArrayList<String> getfilev(File dir) {
		File  listFilev[]= dir.listFiles();
		if (listFilev != null && listFilev.length > 0) {
			for (int i = 0; i < listFilev.length; i++) {

				if (listFilev[i].isDirectory()) {
					getfilev(listFilev[i]);

				} else if (listFilev[i].getName().endsWith(".mp4"))
							
					{
					      
                      
					   vi.put(listFilev[i].getName(), listFilev[i].getPath());
					  
				       video_name.add(listFilev[i].getName());	
						
					}
				else
				{
					continue;
				}
				}

			}
		  Collections.sort(video_name,String.CASE_INSENSITIVE_ORDER);
             ArrayAdapter<String>  videoList = new ArrayAdapter<String>(this,R.layout.text,R.id.textView1,video_name);
		
		     setListAdapter(videoList);
	        	return video_name;
		

	}


	}
