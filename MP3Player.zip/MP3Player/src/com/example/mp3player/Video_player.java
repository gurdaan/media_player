package com.example.mp3player;

import android.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class Video_player extends Activity{
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_screen);
		Intent intent=getIntent();
		String Video_path=intent.getExtras().getString("video_path");
        VideoView vi=(VideoView) findViewById(R.id.videoView1);
        vi.setVideoPath(Video_path);
        vi.setMediaController(new MediaController(this));
        vi.requestFocus();
        vi.start();
}}
