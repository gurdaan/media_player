package com.example.mp3player;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class HomeActivity extends Activity{
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);;
		Thread mythread=new Thread(){
			public void run(){
				try{
					sleep(470);
					Intent inten=new Intent(HomeActivity.this,MainActivity.class);
					startActivity(inten);
					finish();
				}catch(Exception e){}
			}
		};
		
		mythread.start();

}}
